<?php

namespace Rehike\ConfigManager;

// Prereq coffeeexception
class FilePathException extends \YukisCoffee\CoffeeException {};