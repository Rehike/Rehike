<?php

namespace Rehike\ConfigManager;

// Prereq coffeeexception
class DumpFileException extends \YukisCoffee\CoffeeException {};