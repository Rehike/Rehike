<?php

namespace Rehike\ConfigManager;

// Prereq coffeeexception
class LoadConfigException extends \YukisCoffee\CoffeeException {};