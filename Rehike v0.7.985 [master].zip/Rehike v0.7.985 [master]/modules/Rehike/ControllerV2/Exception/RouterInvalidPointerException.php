<?php
namespace Rehike\ControllerV2\Exception;

use YukisCoffee\CoffeeException;

class RouterInvalidPointerException extends CoffeeException {}