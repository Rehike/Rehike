<?php
namespace Rehike\ControllerV2\Exception;

use YukisCoffee\CoffeeException;

class MethodDoesNotExistException extends CoffeeException {}