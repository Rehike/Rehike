<?php
namespace Rehike\Player\Exception;

class CacherException extends BaseException {}