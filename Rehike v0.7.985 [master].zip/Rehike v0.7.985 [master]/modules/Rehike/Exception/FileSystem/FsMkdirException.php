<?php
namespace Rehike\Exception\FileSystem;

use Rehike\Exception\AbstractException;

class FsMkdirException extends AbstractException {}