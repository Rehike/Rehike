<?php
namespace Rehike\Exception\FileSystem;

use Rehike\Exception\AbstractException;

class FsFileDoesNotExistException extends AbstractException {}