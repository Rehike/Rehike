<?php
namespace Rehike\Exception\FileSystem;

use Rehike\Exception\AbstractException;

class FsWriteFileException extends AbstractException {}