<?php
namespace Rehike\Exception\FileSystem;

use Rehike\Exception\AbstractException;

class FsFileReadFailureException extends AbstractException {}