<?php
namespace Rehike\Exception\Network;

use Rehike\Exception\AbstractException;

class InnertubeFailedRequestException extends AbstractException {}