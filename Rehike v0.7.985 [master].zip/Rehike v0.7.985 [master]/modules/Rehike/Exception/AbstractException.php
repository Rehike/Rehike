<?php
namespace Rehike\Exception;

use YukisCoffee\CoffeeException;

abstract class AbstractException extends CoffeeException {}