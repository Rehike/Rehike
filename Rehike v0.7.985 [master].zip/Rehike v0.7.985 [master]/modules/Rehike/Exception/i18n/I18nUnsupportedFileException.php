<?php
namespace Rehike\Exception\i18n;

use Rehike\Exception\AbstractException;

class I18nUnsupportedFileException extends AbstractException {}