<?php
require "modules/Rehike/ErrorHandler/ErrorHandler.php";