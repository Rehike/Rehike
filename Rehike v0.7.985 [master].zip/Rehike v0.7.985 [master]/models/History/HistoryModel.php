<?php
namespace Rehike\Model\History;

class HistoryModel {
    public static function bake($dataHost) {
        return $dataHost;
    }
}