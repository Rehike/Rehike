<?php
namespace Rehike\Model\Picker;

class PickerModel {
    /**  */
    public static $flagMap = [

    ];

    public static function bake($dataHost, $action) {
        $response = (object) [];
       
    }
}