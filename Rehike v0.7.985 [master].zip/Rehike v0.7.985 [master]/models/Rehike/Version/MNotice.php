<?php
namespace Rehike\Model\Rehike\Version;

use Rehike\i18n;

class MNotice
{
    public $text;
    public $description;
}