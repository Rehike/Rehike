<?php
namespace Rehike\Model\Rehike\Debugger;

/**
 * TODO!!
 * 
 * @author Taniko Yamamoto <kirasicecreamm@gmail.com>
 * @author The Rehike Developers
 */
class MNetworkTab extends MTabContent
{
    // This should not update over SPF
    public $enableJsHistory = false;

    public function __construct()
    {
        
    }
}